package com.java;

public class MaxDiffInAnArray {

	public static void main(String[] args) {

		int[] arr = new int[]{1,2,6,4};
		System.out.println(maxDiff(arr, arr.length-1));
	}
	private static int maxDiff(int[] arr, int length){
		int maxDiff = -1;
		for(int i = length; i >= 0; i--){
			for(int j = i-1; j >= 0; j--){
				if(arr[i] > arr[j] && (arr[i]-arr[j]) > maxDiff){
					maxDiff = arr[i]-arr[j];
				}
			}
		} 
		return maxDiff;
	}
}
