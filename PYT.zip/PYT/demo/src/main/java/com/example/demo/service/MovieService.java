package com.example.demo.service;

import java.util.List;

public interface MovieService {

	List<String> getMoviesTitle(String title);
	
}
