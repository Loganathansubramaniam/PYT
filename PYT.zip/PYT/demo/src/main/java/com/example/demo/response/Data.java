package com.example.demo.response;

import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class Data implements Serializable{

	private static final long serialVersionUID = -1363092154236552727L;

	@JsonDeserialize
	private String Poster;
	@JsonDeserialize
	private String Title;
	@JsonDeserialize
	private String Type;
	@JsonDeserialize
	private String Year;
	private String imdbID;
	
	public String getPoster() {
		return Poster;
	}
	public void setPoster(String poster) {
		Poster = poster;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public String getYear() {
		return Year;
	}
	public void setYear(String year) {
		Year = year;
	}
	public String getImdbID() {
		return imdbID;
	}
	public void setImdbID(String imdbID) {
		this.imdbID = imdbID;
	}
	
	
}
