package com.example.demo.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class TitleResponseFromAPI implements Serializable{

	private static final long serialVersionUID = -5002935360510219304L;

	private String page;
	private String per_page;
	private String total;
	private String total_pages;
	private List<Data> data;
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getPer_page() {
		return per_page;
	}
	public void setPer_page(String per_page) {
		this.per_page = per_page;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getTotal_pages() {
		return total_pages;
	}
	public void setTotal_pages(String total_pages) {
		this.total_pages = total_pages;
	}
	public List<Data> getData() {
		if(null == data){
			data = new ArrayList<>();
		}
		return data;
	}
	public void setData(List<Data> data) {
		this.data = data;
	}
	
	
}
