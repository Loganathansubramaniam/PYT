package com.example.demo.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.config.MoviesConfig;
import com.example.demo.response.MoviesTitleResonse;
import com.example.demo.response.TitleResponseFromAPI;
import com.example.demo.service.MovieService;

@Service
public class MovieServiceImpl implements MovieService{
	
	@Autowired
	MoviesConfig moviesConfig;
	
	@Override
	public List<String> getMoviesTitle(String title) {
		MoviesTitleResonse response = new MoviesTitleResonse();
		String resourceUrl = null;
		if(null != title){
			resourceUrl = moviesConfig.getMovieURI()+"?"+"Title="+title;
		}else{
			resourceUrl = moviesConfig.getMovieURI();
		}
		RestTemplate restTemplate = new RestTemplate();
		
		TitleResponseFromAPI titleResponse = restTemplate.getForObject(resourceUrl, TitleResponseFromAPI.class);
		String total_pages = null;
		if(null != titleResponse && null != titleResponse.getData() && !titleResponse.getData().isEmpty()){
			total_pages = titleResponse.getTotal_pages();
			response.setMoviesTitleList(titleResponse.getData().stream().map(t -> t.getTitle()).collect(Collectors.toList()));
		}
		
		if(null != total_pages){
			List<Callable<TitleResponseFromAPI>> titleList = new ArrayList<>();
			ExecutorService executor = Executors.newFixedThreadPool(Integer.valueOf(total_pages));
			for(int i = 2; i <= Integer.valueOf(total_pages); i++){
				if(null != title){
					resourceUrl = resourceUrl+"&"+"page="+i;
				}else{
					resourceUrl = resourceUrl+"?page="+i;
				}
				titleList.add(getMovieTitlesAsync(restTemplate, resourceUrl));
			}
			try{
				List<Future<TitleResponseFromAPI>> futList = executor.invokeAll(titleList);
				for(Future<TitleResponseFromAPI> fut : futList){
					if(null != fut.get()){
						TitleResponseFromAPI res = fut.get();
						if(null != res && null != res.getData() && !res.getData().isEmpty()){
							response.add(res.getData().stream().map(t -> t.getTitle()).collect(Collectors.toList()));
						}
					}
				}
			}catch(InterruptedException | ExecutionException e){
				//Handle exception here
			}finally{
				if(null != executor){
					executor.shutdown();
				}
			}
		}
		
		//Sort the response
		Collections.sort(response.getMoviesTitleList());
		
		return response.getMoviesTitleList();
	}
	
	private Callable<TitleResponseFromAPI> getMovieTitlesAsync(RestTemplate restTemplate, String resourceUrl){
		Callable<TitleResponseFromAPI> callable = () -> {
			TitleResponseFromAPI res = restTemplate.getForObject(resourceUrl, TitleResponseFromAPI.class);
			return res;
		};
		return callable;
	}

	
}
