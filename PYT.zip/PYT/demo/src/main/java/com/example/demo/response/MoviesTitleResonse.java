package com.example.demo.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MoviesTitleResonse implements Serializable{
	
	private static final long serialVersionUID = -3385130147070653568L;

	private List<String> moviesTitleList;

	public List<String> getMoviesTitleList() {
		if(null == moviesTitleList){
			moviesTitleList = new ArrayList<>();
		}
		return moviesTitleList;
	}

	public void setMoviesTitleList(List<String> moviesTitleList) {
		this.moviesTitleList = moviesTitleList;
	}
	
	public void add(List<String> titleList){
		titleList.stream().forEach(t -> getMoviesTitleList().add(t));
		
	}
	
}
