package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.MovieService;

@RestController("getMovieTitles")
public class MoviesController {
	
	@Autowired
	MovieService movieService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<String> getMovieTitles(HttpServletRequest req, HttpServletResponse res){
		List<String> response = null;
		if(req != null){
			String title = req.getParameter("title");
			 response = movieService.getMoviesTitle(title);
		}
		return response;
	}

}
