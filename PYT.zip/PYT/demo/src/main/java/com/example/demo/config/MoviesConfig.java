package com.example.demo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class MoviesConfig {

	@Value("${movieURI}")
	String movieURI;

	public String getMovieURI() {
		return movieURI;
	}

	public void setMovieURI(String movieURI) {
		this.movieURI = movieURI;
	}


}
