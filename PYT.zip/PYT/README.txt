Problem 1:
Import demo as a maven project.
Once dependencies are downloaded, open DemoApplication.java and run as a java application
Once the tomcat service is up, hit the below url in the browser and test (Port is 8090 which is configured in application.properties)
http://localhost:8090/getMovieTitles?title=Spiderman

Problem 2 & 3:
Run as a java application