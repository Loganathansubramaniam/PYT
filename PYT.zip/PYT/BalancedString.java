package com.java;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BalancedString {

	public static void main(String args[]){
		String val = "cdcdaabb";
		System.out.println(isBalancedString(val));
	}
	private static boolean isBalancedString(String val){
		char[] charArr = val.toCharArray();
		List<String> balancedList = new ArrayList<>();
		for(char c : charArr){
			balancedList.add(String.valueOf(c));
		}
		long countOfA = getCount(balancedList, "a");
		long countOfB = getCount(balancedList, "b");
		long countOfC = getCount(balancedList, "c");
		long countOfD = getCount(balancedList, "d");
		long sumOfAandC = countOfA+countOfC;
		long sumOfBandD = countOfB+countOfD;
		return (sumOfAandC%2==0 && sumOfBandD%2==0) ? true : false ;
	}
	private static long getCount(List<String> balancedList, String match){
		return balancedList.stream().filter(s ->
		s.equalsIgnoreCase(match)).collect(Collectors.counting());
	}

}
